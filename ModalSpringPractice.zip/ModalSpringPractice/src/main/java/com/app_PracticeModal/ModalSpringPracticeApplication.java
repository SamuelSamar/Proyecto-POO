package com.app_PracticeModal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModalSpringPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModalSpringPracticeApplication.class, args);
	}

}
