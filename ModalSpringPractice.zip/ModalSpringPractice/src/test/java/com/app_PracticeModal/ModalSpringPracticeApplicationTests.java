package com.app_PracticeModal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModalSpringPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
